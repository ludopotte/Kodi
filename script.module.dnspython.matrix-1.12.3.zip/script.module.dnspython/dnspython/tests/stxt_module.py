import dns.rdtypes.txtbase


class STXT(dns.rdtypes.txtbase.TXTBase):
    """Test singleton TXT-like record"""
