Rdataclasses
============

.. py:data:: dns.rdataclass.ANY
   :annotation: = 255
.. py:data:: dns.rdataclass.CH
   :annotation: = 3
.. py:data:: dns.rdataclass.CHAOS
   :annotation: = 3
.. py:data:: dns.rdataclass.HESIOD
   :annotation: = 4
.. py:data:: dns.rdataclass.HS
   :annotation: = 4
.. py:data:: dns.rdataclass.IN
   :annotation: = 1
.. py:data:: dns.rdataclass.INTERNET
   :annotation: = 1
.. py:data:: dns.rdataclass.NONE
   :annotation: = 254
.. py:data:: dns.rdataclass.RESERVED0
   :annotation: = 0
