.. _name-make:

Making DNS Names
----------------

.. autofunction:: dns.name.from_text
.. autofunction:: dns.name.from_unicode
.. autofunction:: dns.name.from_wire_parser
.. autofunction:: dns.name.from_wire
