.. examples:

Examples
--------

The dnspython source comes with example programs that show how
to use dnspython in practice. You can clone the dnspython source
from GitHub:

        git clone https://github.com/rthalley/dnspython.git

The example prgrams are in the ``examples/`` directory.
