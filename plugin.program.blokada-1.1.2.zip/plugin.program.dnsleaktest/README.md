# plugin.program.dnsleaktest
![](https://github.com/Space2Walker/plugin.program.dnsleaktest/workflows/Kodi-Addon-Check/badge.svg)
## DNS leak Test Addon for KODI
Compatible to [Kodi](https://kodi.tv/)-17.6 and above.

This Addon performs a DNS leak test on [bash.ws](https://bash.ws/dnsleak)!

The Basic Code comes from [macvk](https://github.com/macvk/dnsleaktest).

This Addon should work on all Platorms.
